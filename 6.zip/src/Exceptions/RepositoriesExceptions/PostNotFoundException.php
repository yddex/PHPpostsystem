<?php
namespace Maxim\Postsystem\Exceptions\RepositoriesExceptions;

use Maxim\Postsystem\Exceptions\AppException;

class PostNotFoundException extends AppException {}