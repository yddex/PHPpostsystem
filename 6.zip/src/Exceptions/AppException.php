<?php
namespace Maxim\Postsystem\Exceptions;

use Exception;

class AppException extends Exception{}