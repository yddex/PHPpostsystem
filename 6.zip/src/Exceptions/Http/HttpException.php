<?php
namespace Maxim\Postsystem\Exceptions\Http;

use Maxim\Postsystem\Exceptions\AppException;

class HttpException extends AppException{}
