<?php
namespace Maxim\Postsystem\UnitTests\Container\ContainerTestClasses;

class SomeClassWithoutDependencies {}