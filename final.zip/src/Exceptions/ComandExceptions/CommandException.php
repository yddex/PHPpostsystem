<?php
namespace Maxim\Postsystem\Exceptions\ComandExceptions;

use Maxim\Postsystem\Exceptions\AppException;

class CommandException extends AppException {}