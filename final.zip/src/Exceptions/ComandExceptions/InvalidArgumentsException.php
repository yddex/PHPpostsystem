<?php
namespace Maxim\Postsystem\Exceptions\ArgumentsExceptions;

use Maxim\Postsystem\Exceptions\AppException;

class InvalidArgumentsException extends AppException{}