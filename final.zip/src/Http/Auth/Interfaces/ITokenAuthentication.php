<?php
namespace Maxim\Postsystem\Http\Auth\Interfaces;

use Maxim\Postsystem\Http\Auth\IAuthentication;

interface ITokenAuthentication extends IAuthentication {}